
#!/bin/bash
open ./Installer/CloverOSXBaseSystem.pkg
