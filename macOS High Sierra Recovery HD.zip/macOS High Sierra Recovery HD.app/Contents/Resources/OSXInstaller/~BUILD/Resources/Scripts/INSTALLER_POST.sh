
#!/bin/bash
open ./Installer/PostInstallerOSXBaseSystem.pkg
